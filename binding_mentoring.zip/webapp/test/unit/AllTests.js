sap.ui.define([
	"hyunsap.training./binding_mentoring/test/unit/controller/App.controller"
], function () {
	"use strict";
});
